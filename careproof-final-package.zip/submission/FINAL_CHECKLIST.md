# Final submission checklist

## Completed

- [x] Kaggle competition joined and rules accepted
- [x] CareProof reliability protocol implemented
- [x] Submission YAML created and schema-validated
- [x] Prompt-boundary tests added
- [x] Complete unit suite: 264 passed, 6 skipped
- [x] Kaggle writeup drafted
- [x] Reproducibility manifest drafted
- [x] Technical report source and PDF prepared
- [x] No credentials, real patient data, or protected handbook content included

## Gated prerequisites

- [ ] Hugging Face sign-in completed
- [ ] Handbook access request submitted
- [ ] Handbook access approved by actAVA
- [ ] `HF_TOKEN` from the approved account configured privately
- [ ] Agent-model and official-judge API credentials configured privately

## Official evaluation and delivery

- [ ] Download complete pinned public dataset and authorized handbook
- [ ] Run full preflight without `--skip-preflight`
- [ ] Execute all 75 public tasks once
- [ ] Review official verifier evidence; never edit rewards manually
- [ ] Generate `submission.csv` from verifier rewards
- [ ] Prepare the official audit packet
- [ ] Publish the Kaggle writeup
- [ ] Submit the Kaggle CSV
- [ ] Email the runnable package/report link to `research@actava.ai` with a
      subject beginning `[Kaggle]` and include the team name and writeup link

