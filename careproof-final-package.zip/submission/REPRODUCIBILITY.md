# CareProof reproducibility manifest

## Frozen system

| Item | Value |
|---|---|
| Submission ID | `careproof-gpt-5-6-sol` |
| Team | `nithin-builds` |
| Agent harness | `openai-agents` |
| Agent model | `openai/gpt-5.6-sol` |
| Dataset revision | `chi-bench-v1.0.0` |
| Domains | `pa_provider`, `pa_um`, `cm` |
| Attempts | `1` |
| Concurrency | `5` |
| Timeout multiplier | `2.0` |

## Required private environment variables

- `OPENAI_API_KEY` - agent model access
- `ANTHROPIC_API_KEY` - official workspace judge and simulators
- `HF_TOKEN` - token belonging to a user approved for the gated handbook
- Modal credentials when `run.environment: modal` is used

Never place these values in the repository, Kaggle writeup, report, evidence
packet, or archive.

## Validation commands

```bash
uv sync --extra dev
uv run pytest tests/unit -q
uv run cb submission validate \
  -f configs/submissions/careproof-gpt-5-6-sol.yaml \
  --skip-preflight
```

## Authorized full run

Run only after handbook approval:

```bash
uv run hf download actava/chi-bench \
  --repo-type dataset \
  --revision chi-bench-v1.0.0 \
  --local-dir data
printf '%s\n' chi-bench-v1.0.0 > data/.chi-bench-version

uv run hf download actava/managed-care-operations-handbook \
  --repo-type dataset \
  --local-dir data/skills/managed-care-operations-handbook

uv run cb submission validate \
  -f configs/submissions/careproof-gpt-5-6-sol.yaml
uv run cb submission run \
  -f configs/submissions/careproof-gpt-5-6-sol.yaml
uv run cb submission status \
  -f configs/submissions/careproof-gpt-5-6-sol.yaml
uv run cb submission prepare \
  -f configs/submissions/careproof-gpt-5-6-sol.yaml
```

## Evidence policy

Only official verifier outputs may populate `submission.csv` or reported
benchmark results. A task receives `1` only when its official verifier reward is
`1`; otherwise it receives `0`. Unit-test counts are not model-quality scores.

