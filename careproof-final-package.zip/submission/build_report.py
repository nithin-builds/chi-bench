from __future__ import annotations

from pathlib import Path

from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageTemplate,
    Paragraph,
    Spacer,
)


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "careproof_technical_report.pdf"


def page_number(canvas, doc) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(HexColor("#555555"))
    canvas.drawCentredString(letter[0] / 2, 0.35 * inch, f"{doc.page}")
    canvas.restoreState()


def build() -> None:
    pdfmetrics.registerFont(TTFont("DejaVuSans", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
    pdfmetrics.registerFont(
        TTFont("DejaVuSans-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
    )
    pdfmetrics.registerFont(TTFont("DejaVuSerif", "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"))
    margin = 0.55 * inch
    gap = 0.22 * inch
    width = (letter[0] - 2 * margin - gap) / 2
    height = letter[1] - 1.05 * inch
    frames = [
        Frame(margin, 0.52 * inch, width, height, id="left", leftPadding=0, rightPadding=0),
        Frame(
            margin + width + gap,
            0.52 * inch,
            width,
            height,
            id="right",
            leftPadding=0,
            rightPadding=0,
        ),
    ]
    doc = BaseDocTemplate(
        str(OUTPUT),
        pagesize=letter,
        leftMargin=margin,
        rightMargin=margin,
        topMargin=margin,
        bottomMargin=0.52 * inch,
        title="CareProof Agent: Verified-State Control for Reliable Healthcare Workflows",
        author="N Nithin Kumar",
    )
    doc.addPageTemplates([PageTemplate(id="two-column", frames=frames, onPage=page_number)])

    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "Title",
        parent=styles["Title"],
        fontName="DejaVuSans-Bold",
        fontSize=13.2,
        leading=15,
        alignment=TA_CENTER,
        spaceAfter=7,
    )
    author = ParagraphStyle(
        "Author",
        parent=styles["Normal"],
        fontName="DejaVuSans",
        fontSize=7.7,
        leading=9,
        alignment=TA_CENTER,
        spaceAfter=8,
    )
    heading = ParagraphStyle(
        "Heading",
        parent=styles["Heading2"],
        fontName="DejaVuSans-Bold",
        fontSize=9.2,
        leading=10.5,
        spaceBefore=5,
        spaceAfter=2,
    )
    body = ParagraphStyle(
        "Body",
        parent=styles["BodyText"],
        fontName="DejaVuSerif",
        fontSize=7.3,
        leading=8.65,
        alignment=0,
        spaceAfter=2.5,
    )
    small = ParagraphStyle("Small", parent=body, fontSize=6.8, leading=8)

    story = [
        Paragraph("CareProof Agent: Verified-State Control for Reliable Healthcare Workflows", title),
        Paragraph(
            "N Nithin Kumar - Team nithin-builds<br/>"
            "RCR Institute of Technology and Management, Tirupati, India<br/>"
            "χ-Bench Healthcare AI Agents Challenge",
            author,
        ),
        Paragraph("Abstract", heading),
        Paragraph(
            "χ-Bench evaluates long-horizon agents on simulated provider prior authorization, "
            "payer utilization management, and care management. Its strict binary reward makes "
            "near-complete workflows equivalent to failures. CareProof is a reliability-focused "
            "control protocol integrated with the official OpenAI Agents harness. It constrains "
            "scope, separates evidence from unknowns, orders dependencies, verifies mutations, "
            "and requires proof of terminal state. The method contains no task-specific answers "
            "or protected handbook content and is intended to generalize to private tasks.",
            body,
        ),
        Paragraph("1. Problem", heading),
        Paragraph(
            "Healthcare-administration workflows combine clinical evidence, policy, operational "
            "state machines, structured artifacts, and conversations. A capable language model "
            "can still fail by skipping one prerequisite, acting outside its role, duplicating a "
            "record, inferring consent, or stopping after an intermediate action. Under χ-Bench's "
            "all-checks-must-pass reward, these control failures dominate plausible but incomplete "
            "answers.",
            body,
        ),
        Paragraph("2. Design objectives", heading),
        Paragraph(
            "CareProof targets four objectives: (1) procedural completeness, (2) evidence "
            "fidelity, (3) mutation safety, and (4) reproducible final-state verification. "
            "Efficiency remains secondary to correctness, although the protocol explicitly "
            "discourages unnecessary calls and duplicate creation.",
            body,
        ),
        Paragraph("3. Reliability protocol", heading),
        Paragraph(
            "The controller first extracts permitted namespaces, target identity, terminal "
            "objective, and prohibitions. It then reads the authorized handbook index and task "
            "tool reference. A private evidence ledger records sourced facts, missing facts, and "
            "conflicts. Before mutation, the agent inspects current state and exact tool schemas. "
            "Actions proceed in dependency order. Structured errors are interpreted before an "
            "idempotent retry. Every consequential mutation is followed by state verification. "
            "The agent stops only after auditing required artifacts, fields, attachments, routing, "
            "status, and follow-up ownership.",
            body,
        ),
        Paragraph("4. Conversation controls", heading),
        Paragraph(
            "Care-management and peer-to-peer tasks require more than database updates. CareProof "
            "treats identity checks, consent, disclosures, teach-back, refusal, escalation, and "
            "closing as performed transcript events. Consent is never inferred from cooperation. "
            "Unsupported clinical or policy facts are prohibited, and refusals follow the "
            "authorized workflow rather than being optimized away.",
            body,
        ),
        Paragraph("5. Implementation", heading),
        Paragraph(
            "The implementation appends a dedicated reliability protocol to the official "
            "OpenAI Agents system prompt. The submission uses the official MCP connection, local "
            "tool set, retry pipeline, logging, trajectory export, and submission lifecycle. The "
            "frozen configuration identifies openai/gpt-5.6-sol, one attempt per public task, the "
            "chi-bench-v1.0.0 dataset revision, and all three required domains.",
            body,
        ),
        Paragraph("6. Threat model", heading),
        Paragraph(
            "The protocol addresses premature completion, unsupported evidence, wrong-role tools, "
            "duplicate mutations, silent partial failures, conversational shortcutting, and final "
            "state drift. It does not attempt to access hidden expectations, simulator source, "
            "solutions, private tasks, or verifier-only artifacts. Protected handbook material is "
            "loaded only at authorized runtime and is never embedded in source or reports.",
            body,
        ),
        Paragraph("7. Verification", heading),
        Paragraph(
            "Two targeted tests assert that evidence, namespace, consent, simulator-boundary, and "
            "post-mutation verification instructions remain present. The full unit suite completed "
            "with 264 passing tests and 6 environment-dependent skips. The official submission "
            "schema validates. These results demonstrate integration correctness only; they are "
            "not substituted for official benchmark evaluation.",
            body,
        ),
        Paragraph("8. Evaluation policy", heading),
        Paragraph(
            "No public pass@1 or pass^3 value is claimed without an authorized, complete run and "
            "unaltered verifier evidence. The official run requires approved access to the gated "
            "Managed-Care Operations Handbook, the pinned public dataset, an agent-model credential, "
            "and the official judge/simulator credential. Each CSV reward must be copied from the "
            "corresponding official verifier result: 1 only for a verified pass, otherwise 0.",
            body,
        ),
        Paragraph("9. Reproducibility", heading),
        Paragraph(
            "The package includes source, prompt, tests, the official dependency lock, a frozen "
            "submission YAML, exact model routing, setup commands, and an evidence policy. Secrets "
            "are supplied only through private environment variables. The same frozen system must "
            "be used for all private tasks.",
            body,
        ),
        Paragraph("10. Limitations", heading),
        Paragraph(
            "A prompt-level controller cannot guarantee compliance, and LLM behavior remains "
            "nondeterministic. Extra verification can increase latency and tool use. Correctness "
            "depends on model capability, tool contracts, simulator availability, and appropriate "
            "handbook retrieval. The current submission has not claimed official task results "
            "before gated access and evaluation are complete.",
            body,
        ),
        Paragraph("11. Ethics and intended use", heading),
        Paragraph(
            "CareProof is a research artifact for synthetic χ-Bench cases. It is not a medical "
            "device, clinical decision system, or production payer/provider automation product. "
            "No real patient data are used. Consequential real-world healthcare decisions require "
            "qualified human oversight and appropriate legal, clinical, privacy, and security review.",
            body,
        ),
        Paragraph("12. Conclusion", heading),
        Paragraph(
            "CareProof reframes healthcare-agent performance as verified state transition rather "
            "than answer generation. By encoding scope, provenance, dependency, mutation, "
            "conversation, and terminal-state controls in one reusable protocol, the submission "
            "targets recurring failure classes while preserving compatibility with the official "
            "χ-Bench runtime.",
            body,
        ),
        Paragraph("References", heading),
        Paragraph(
            "[1] H. Chen et al., “CHI-Bench: Can AI Agents Automate End-to-End, Long-Horizon, "
            "Policy-Rich Healthcare Workflows?” arXiv:2605.16679, 2026.<br/>"
            "[2] actAVA AI, “χ-Bench,” official repository and competition documentation, 2026.<br/>"
            "[3] OpenAI, “OpenAI Agents SDK,” software documentation, 2026.",
            small,
        ),
        Spacer(1, 4),
    ]
    doc.build(story)


if __name__ == "__main__":
    build()

