from chi_bench.experiment.agents.openai_agents_runner import SYSTEM_PROMPT


def test_careproof_protocol_is_present() -> None:
    assert "<careproof_reliability_protocol>" in SYSTEM_PROMPT
    assert "Never invent clinical evidence" in SYSTEM_PROMPT
    assert "read back or otherwise verify" in SYSTEM_PROMPT


def test_careproof_protocol_preserves_benchmark_safety_boundaries() -> None:
    assert "Never use a namespace outside that scope" in SYSTEM_PROMPT
    assert "Do not read simulator" in SYSTEM_PROMPT
    assert "Never infer consent" in SYSTEM_PROMPT
